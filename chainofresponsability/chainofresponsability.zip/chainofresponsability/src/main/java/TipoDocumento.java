public interface TipoDocumento {

}